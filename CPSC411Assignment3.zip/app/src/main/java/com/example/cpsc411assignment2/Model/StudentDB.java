package com.example.cpsc411assignment2.Model;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.io.File;
import java.util.ArrayList;

public class StudentDB {

    private Context context;
    private SQLiteDatabase mSQLiteDatabase;

    public StudentDB(Context c){
        context = c;
        File dbFile = c.getDatabasePath("student.db");
        mSQLiteDatabase = SQLiteDatabase.openOrCreateDatabase(dbFile, null);
        // Create Person and Vehicle tables if needed
        createSQLTables();
        retrievePersonObjects();
        //createPersonObjects();
    }

   // public static final StudentDB ourInstance = new StudentDB();

    private ArrayList<Student> mStudentList;


    /*static public StudentDB getInstance() {
        return ourInstance;
    } */



    private StudentDB() { createPersonObjects(); }

    public ArrayList<Student> getStudentList() {
        return mStudentList;
    }

    public void setStudentList(ArrayList<Student> studentList) {
        mStudentList = studentList;
    }

    public ArrayList<Student> retrievePersonObjects() {
        ArrayList<Student> studentList = new ArrayList<Student>();
        Cursor cursor = mSQLiteDatabase.query("STUDENT", null, null, null, null, null,null );
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                Student pObj = new Student();
                pObj.initFrom(cursor, mSQLiteDatabase);
                studentList.add(pObj);
            }
        }
        mStudentList = studentList;
        return studentList;
    }


    public void addStudent(Student sObj){
        sObj.insert(mSQLiteDatabase);
        mStudentList.add(sObj);
    }




    protected void createSQLTables(){
        String sql = "CREATE TABLE IF NOT EXISTS STUDENT (FirstName Text, LastName Text, CWID INTEGER)";
        mSQLiteDatabase.execSQL(sql);
        sql = "CREATE TABLE IF NOT EXISTS COURSE (ID Text, Grade Text, Owner INTEGER)";
        mSQLiteDatabase.execSQL(sql);
    }

    protected void createPersonObjects() {
        Student student = new Student("James", "Shen", 1234567);
        ArrayList<CourseEnrollment> courses = new ArrayList<CourseEnrollment>();
        courses.add(new CourseEnrollment("MATH370", "B",1234567));
        courses.add(new CourseEnrollment("CPSC223", "A",1234567));
        student.setCourses(courses);
        mStudentList = new ArrayList<Student>();
        student.insert(mSQLiteDatabase);
        mStudentList.add(student);

        student = new Student("John", "Chang", 7654321);
        courses = new ArrayList<CourseEnrollment>();
        courses.add(new CourseEnrollment("CPSC481", "A",7654321));
        student.setCourses(courses);
        student.insert(mSQLiteDatabase);
        mStudentList.add(student);

        student = new Student("Traci", "Trojan", 2468642);
        courses = new ArrayList<CourseEnrollment>();
        courses.add(new CourseEnrollment("CPSC411", "A",2468642));
        student.setCourses(courses);
        student.insert(mSQLiteDatabase);
        mStudentList.add(student);
    }
}

