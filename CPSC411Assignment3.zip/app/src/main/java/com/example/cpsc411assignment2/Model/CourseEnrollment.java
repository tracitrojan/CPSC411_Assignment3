package com.example.cpsc411assignment2.Model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class CourseEnrollment extends PersistentObject {

    protected String mCourseID;
    protected String mGrade;
    protected int mOwner;

    //protected ArrayList<CourseEnrollment> mCourses;

    public CourseEnrollment(){}

    public CourseEnrollment(String courseID, String grade, int owner) {
        mCourseID = courseID;
        mGrade = grade;
        mOwner = owner;
    }

    public String getCourseID() {
        return mCourseID;
    }

    public void setCourseID(String courseID) {
        mCourseID = courseID;
    }

    public String getGrade() {
        return mGrade;
    }

    public void setGrade(String grade) {
        mGrade = grade;
    }

    /*
    public ArrayList<CourseEnrollment> getCourses() {
        return mCourses;
    }

    public void setCourses(ArrayList<CourseEnrollment> courses) {
        mCourses = courses;
    }*/

    @Override
    public void insert(SQLiteDatabase db) {
        ContentValues vals = new ContentValues();
        vals.put("ID", mCourseID);
        vals.put("Grade", mGrade);
        vals.put("Owner", mOwner);
        db.insert("COURSE", null, vals);
    }

    @Override
    public void initFrom(Cursor c, SQLiteDatabase db) {
        mCourseID = c.getString(c.getColumnIndex("ID"));
        mGrade = c.getString(c.getColumnIndex("Grade"));
        mOwner = c.getInt(c.getColumnIndex("Owner"));

    }
}
