package com.example.cpsc411assignment2;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import java.io.File;

public class DbActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Create a new database
        File dbFile = this.getDatabasePath("assignment3.db");
        SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(dbFile, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS Student (FirstName TEXT, LastName TEXT, CWID INTEGER)");
        // 1.
        db.execSQL("DELETE FROM Student WHERE CWID=?", new String[]{"7586698"});
        db.execSQL("INSERT INTO Student VALUES ('James', 'Shen', 7586698)");
        // 2.
        db.delete("Student", "CWID=?", new String[]{"8746677"});
        db.execSQL("INSERT INTO Student VALUES (?, ?, ?)", new String[]{"Mary", "Hsu", "8746677"});
        // 3.
        db.execSQL("DELETE FROM Student WHERE CWID=?", new String[]{"7484865"});
        ContentValues values = new ContentValues();
        values.put("FirstName", "Jerry");
        values.put("LastName", "Ramos");
        values.put("CWID", 7484865);
        db.insert("Student", null, values);

        Cursor c = db.query("Student", null, null, null, null, null, null);

        if (c.getCount() > 0) {
            while (c.moveToNext()) {
                String fName = c.getString(c.getColumnIndex("FirstName"));
                String lName = c.getString(c.getColumnIndex("LastName"));
                //
                Log.d("Database Log", "First Name: " + fName + "; " +"Last Name: " + lName);
            }
        }

        // update
        ContentValues val = new ContentValues();
        val.put("FirstName", "Rudy");
        db.update("Student", val, "CWID=?", new String[]{"7484866"});
        db.close();
    }
}
